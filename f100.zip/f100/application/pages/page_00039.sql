prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Informe Pedidos Completados'
,p_alias=>'INFORME-PEDIDOS-COMPLETADOS'
,p_step_title=>'Informe Pedidos Completados'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624052707'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16638248335868135)
,p_plug_name=>'Informe Pedidos Completados'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       FECHAENTREGA,',
'       ep.nomb',
'  from PEDIDO p,',
'  estadopedidos ep',
'  where p.IDESTADOPEDIDO=ep.ID',
'  and ep.id=1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Informe Pedidos Completados'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16638354180868135)
,p_name=>'Informe Pedidos Completados'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>16638354180868135
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16638759996868139)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>unistr('N\00B0 Pedido')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16640368426868140)
,p_db_column_name=>'FECHAENTREGA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fecha de Entrega'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-RR'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16593717722677321)
,p_db_column_name=>'NOMB'
,p_display_order=>17
,p_column_identifier=>'H'
,p_column_label=>'Estado del Pedido'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16642603513876723)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'166427'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'ID:FECHAENTREGA:NOMB'
,p_chart_type=>'bar'
,p_chart_label_column=>'FECHAENTREGA'
,p_chart_label_title=>'Fecha de Entrega'
,p_chart_value_column=>'ID'
,p_chart_aggregate=>'COUNT'
,p_chart_value_title=>'Pedidos'
,p_chart_sorting=>'VALUE_ASC'
,p_chart_orientation=>'vertical'
);
wwv_flow_api.component_end;
end;
/
