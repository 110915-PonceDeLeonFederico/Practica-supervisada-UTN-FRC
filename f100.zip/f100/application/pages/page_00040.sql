prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>40
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Causas comunes de Reclamos'
,p_alias=>'CAUSAS-COMUNES-DE-RECLAMOS'
,p_step_title=>'Causas comunes de Reclamos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624052753'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33291214401806588)
,p_plug_name=>'Reporte Causas Comunes de Reclamo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COUNT(r.ID) "Cantidad de Reclamos",',
'       c.nomb "Causa del Reclamo"',
'  from RECLAMOS r,',
'  Causas c',
'  where r."nCausa"=c.id',
'  group by c.nomb'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Informe Pedidos Completados'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(33291320246806588)
,p_name=>'Informe Pedidos Completados'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No hay datos para mostrar.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>33291320246806588
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16594715724677331)
,p_db_column_name=>'Cantidad de Reclamos'
,p_display_order=>10
,p_column_identifier=>'O'
,p_column_label=>'Cantidad De Reclamos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16594841781677332)
,p_db_column_name=>'Causa del Reclamo'
,p_display_order=>20
,p_column_identifier=>'P'
,p_column_label=>'Causa Del Reclamo'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(33295569579815176)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'166554'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'Cantidad de Reclamos:Causa del Reclamo'
,p_chart_type=>'pie'
,p_chart_label_column=>'Causa del Reclamo'
,p_chart_value_column=>'Cantidad de Reclamos'
,p_chart_aggregate=>'SUM'
,p_chart_sorting=>'DEFAULT'
,p_chart_orientation=>'vertical'
);
wwv_flow_api.component_end;
end;
/
