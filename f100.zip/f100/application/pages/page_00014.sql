prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>14
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>unistr('Reporte  Costos de Fabricaci\00F3n x Piezas Fabricadas')
,p_alias=>unistr('REPORTE-COSTOS-DE-FABRICACI\00D3N-X-PIEZAS-FABRICADAS')
,p_step_title=>unistr('Reporte  Costos de Fabricaci\00F3n x Piezas Fabricadas')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210617124521'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10943341612070366)
,p_plug_name=>unistr('Reporte  Costos de Fabricaci\00F3n x Piezas Fabricadas')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('/*COMO personal de gesti\00F3n de stock QUIERO generar un informe '),
unistr('sobre los costos de fabricaci\00F3n por pieza finalizadas PARA informar'),
unistr(' el costo de fabricaci\00F3n de cada tipo de pieza.'),
'Notas:',
unistr('\25CF\00A0\00A0\00A0\00A0\00A0\00A0 Nombre Pieza (Desplegable).'),
unistr('\25CF\00A0\00A0\00A0\00A0\00A0\00A0 Costo de fabricaci\00F3n.'),
unistr('\25CF\00A0\00A0\00A0\00A0\00A0\00A0 Cantidad producida.'),
unistr('\25CF\00A0\00A0\00A0\00A0\00A0\00A0 Tiempo de fabricaci\00F3n.*/'),
'',
unistr('select pie.nomb "Pieza",''$''||p.COSTO "Costo de Fabricaci\00F3n",p.TIEMPOFABR||''Hs'' "Tiempo de Fabricaci\00F3n"'),
'from piezas pie,',
'productos p,',
'estados e',
'where pie.id=p.idPieza',
'and p.IDESTADOPIEZA=e.id',
'and e.id=3',
'group by pie.nomb,p.costo,p.TIEMPOFABR'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>unistr('Reporte  Costos de Fabricaci\00F3n x Piezas Fabricadas')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10943463841070366)
,p_name=>unistr('Reporte  Costos de Fabricaci\00F3n x Piezas Fabricadas')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>10943463841070366
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819954685446125)
,p_db_column_name=>'Pieza'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10820295617446128)
,p_db_column_name=>unistr('Costo de Fabricaci\00F3n')
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>unistr('Costo De Fabricaci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10820381820446129)
,p_db_column_name=>unistr('Tiempo de Fabricaci\00F3n')
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>unistr('Tiempo De Fabricaci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10945946249087066)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'109460'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Pieza:Costo de Fabricaci\00F3n:Tiempo de Fabricaci\00F3n:')
);
wwv_flow_api.component_end;
end;
/
