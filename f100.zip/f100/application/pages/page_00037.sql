prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>37
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
,p_alias=>unistr('REPORTE-PEDIDOS-SEG\00DAN-SU-PRIORIDAD-DE-ENTREGA-DE-FECHAS')
,p_step_title=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210617200111'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16497462786336819)
,p_plug_name=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.ID,',
'       NROFACTURA,',
'       c.nomb||'' ''||c.apel,',
'       HORARIOENTREGA,',
'       fe.nomb "Formas de entrega",',
'       FECHENTREGA,',
'       ea.nomb,',
'       (select trunc(SYSDATE, ''DD'')',
'            - trunc(FECHENTREGA, ''DD'') datediff',
'        from   dual)',
'  from ENTREGAS e,',
'  ESTADOSACEPTACION ea,',
'  Clientes c,',
'  formasEntregas fe',
'  where e.IDESTADOACEPTACION=ea.id',
'  AND e.IDCLIENTE=C.ID',
'  and e.IDFORMAENTREGA=fe.id',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16497505704336819)
,p_name=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>16497505704336819
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16397529731904738)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00B0 Entrega')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16591831858677302)
,p_db_column_name=>'NROFACTURA'
,p_display_order=>50
,p_column_identifier=>'O'
,p_column_label=>unistr('N\00B0 Factura')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16592130919677305)
,p_db_column_name=>'FECHENTREGA'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Fechentrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16593280071677316)
,p_db_column_name=>'NOMB'
,p_display_order=>120
,p_column_identifier=>'AC'
,p_column_label=>'Forma de Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16593588625677319)
,p_db_column_name=>'C.NOMB||''''||C.APEL'
,p_display_order=>140
,p_column_identifier=>'AF'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16593611351677320)
,p_db_column_name=>'Formas de entrega'
,p_display_order=>150
,p_column_identifier=>'AG'
,p_column_label=>'Formas De Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16596421191677348)
,p_db_column_name=>'HORARIOENTREGA'
,p_display_order=>160
,p_column_identifier=>'AJ'
,p_column_label=>'Horarioentrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16596568095677349)
,p_db_column_name=>'(SELECTTRUNC(SYSDATE,''DD'')-TRUNC(FECHENTREGA,''DD'')DATEDIFFFROMDUAL)'
,p_display_order=>170
,p_column_identifier=>'AK'
,p_column_label=>unistr('D\00EDas de Demora')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16498378325337493)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'164984'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID:NROFACTURA:FECHENTREGA:NOMB:C.NOMB||''''||C.APEL:Formas de entrega||''D\00CDA'':(SELECTTRUNC(SYSDATE,''DD'')-TRUNC(FECHENTREGA,''DD'')DATEDIFFFROMDUAL)')
);
wwv_flow_api.component_end;
end;
/
