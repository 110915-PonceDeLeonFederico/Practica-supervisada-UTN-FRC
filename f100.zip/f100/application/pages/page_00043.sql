prompt --application/pages/page_00043
begin
--   Manifest
--     PAGE: 00043
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>43
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Informe sobre las entregas finalizadas'
,p_alias=>'INFORME-SOBRE-LAS-ENTREGAS-FINALIZADAS'
,p_step_title=>'Informe sobre las entregas finalizadas'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624053005'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33417925611659453)
,p_plug_name=>'Informe sobre las entregas finalizadas. '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.ID,',
'        ee.nomb "Estado Entrega",',
'        FECHENTREGA,',
'        HORARIOENTREGA,',
unistr('        ea.nomb "Estado de Aceptaci\00F3n",'),
'       dm.nomb "Constancia de Comprobante"',
'  from ENTREGAS e,',
'  ESTADOSACEPTACION ea,',
'  Clientes c,',
'  formasEntregas fe,',
'  estadoentrega ee,',
'  dm$sino dm',
'  where e.IDESTADOACEPTACION=ea.id',
'  AND e.IDCLIENTE=C.ID',
'  and e.IDFORMAENTREGA=fe.id',
'  and e.IDESTADO=ee.id',
'  and e.Constancia=dm.id',
'  and ee.id=1',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(33417968529659453)
,p_name=>unistr('Reporte Pedidos seg\00FAn su prioridad de entrega de fechas.')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>33417968529659453
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16921664197322715)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00B0 Entrega')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16922889599322716)
,p_db_column_name=>'FECHENTREGA'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Fecha de Entrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16596103188677345)
,p_db_column_name=>'Estado Entrega'
,p_display_order=>90
,p_column_identifier=>'AJ'
,p_column_label=>'Estado de Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16596228373677346)
,p_db_column_name=>unistr('Estado de Aceptaci\00F3n')
,p_display_order=>100
,p_column_identifier=>'AK'
,p_column_label=>unistr('Estado De Aceptaci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16596343650677347)
,p_db_column_name=>'Constancia de Comprobante'
,p_display_order=>110
,p_column_identifier=>'AL'
,p_column_label=>'Constancia De Comprobante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16939302329540504)
,p_db_column_name=>'HORARIOENTREGA'
,p_display_order=>120
,p_column_identifier=>'AM'
,p_column_label=>'Horarioentrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(33418841150660127)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'169248'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID:FECHENTREGA:Estado Entrega:Estado de Aceptaci\00F3n:Constancia de Comprobante')
,p_chart_type=>'bar'
,p_chart_label_column=>'FECHENTREGA'
,p_chart_label_title=>'Fechas Entregas'
,p_chart_value_column=>'ID'
,p_chart_aggregate=>'COUNT'
,p_chart_value_title=>'Cantidad de Entregas'
,p_chart_sorting=>'DEFAULT'
,p_chart_orientation=>'vertical'
);
wwv_flow_api.component_end;
end;
/
