prompt --application/pages/page_10040
begin
--   Manifest
--     PAGE: 10040
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>10040
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Terminos y Condiciones'
,p_alias=>'HELP'
,p_step_title=>'Terminos y Condiciones'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_required_patch=>wwv_flow_api.id(17028171869938671)
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624045413'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17028893032938672)
,p_plug_name=>unistr('T\00E9rminos y Condiciones')
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_api.id(10544402351422913)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>Bienvenido a SISTEMA proporcionado por PROYECTO-VISION.</h2>',
'<br>',
unistr('<p>Nos complace ofrecerle acceso al Sistema, sujeto a estos t\00E9rminos y condiciones (los "T\00E9rminos de Servicio") y a la Pol\00EDtica de Privacidad correspondiente de 2021. Al acceder y utilizar el Servicio, usted expresa su consentimiento, acuerdo y enten')
||unistr('dimiento de los T\00E9rminos de Servicio y la Pol\00EDtica de '),
unistr('Privacidad. Si no est\00E1 de acuerdo con los T\00E9rminos de Servicio o la Pol\00EDtica de Privacidad, no utilice Sistema.</p>'),
'',
unistr('<p>Si utiliza Sistema est\00E1 aceptando las modalidades operativas en vigencia descriptas '),
unistr('m\00E1s adelante, las declara conocer y aceptar, las que se habiliten en el futuro y en los '),
unistr('t\00E9rminos y condiciones que a continuaci\00F3n se detallan las Operaciones habilitadas.</p>'),
'<p>',
unistr('Las operaciones habilitadas son aquellas que estar\00E1n disponibles para los clientes, quienes deber\00E1n cumplir los requisitos que se encuentren vigentes en su momento para operar Sistema.'),
unistr('Las mismas podr\00E1n ser ampliadas o restringidas por el proveedor, '),
unistr('comunic\00E1ndolo previamente con una antelaci\00F3n no menor a 60 d\00EDas, y comprenden '),
unistr('entre otras, sin que pueda entenderse taxativamente las que se indican a continuaci\00F3n: '),
'<ul>',
'<li><b>Sobre las Transacciones :</b></li>',
'<p>',
unistr('  <li type="circle" style="margin-left: 30px;">En ning\00FAn caso debe entenderse que la solicitud de un producto o servicio implica obligaci\00F3n alguna para el Acceso y uso del Servicio.</li>'),
unistr('  <li type="circle" style="margin-left: 30px;">Para operar el Servicio se requerir\00E1 siempre que se trate de clientes de PROYECTO-VISION, quienes '),
unistr('podr\00E1n acceder mediante cualquier dispositivo con conexi\00F3n a la Red Internet.</li>'),
'<li type="circle" style="margin-left: 30px;">El cliente ',
unistr('deber\00E1 proporcionar el n\00FAmero de documento de identidad y la clave personal, que ser\00E1 '),
unistr('provista por la aplicaci\00F3n como requisito previo a la primera operaci\00F3n, en la forma que '),
'le sea requerida.</li>',
'<li type="circle" style="margin-left: 30px;">La clave personal y todo o cualquier otro mecanismo adicional de ',
unistr('autenticaci\00F3n personal provisto por el Banco tiene el car\00E1cter de secreto e intransferible, '),
unistr('y por lo tanto asumo las consecuencias de su divulgaci\00F3n a terceros, liberando a PROYECTO-VISION '),
'de toda responsabilidad que de ello se derive.</li>',
unistr('<li type="circle" style="margin-left: 30px;text-transform: uppercase;"><b>En ning\00FAn caso PROYECTO-VISION  requerir\00E1 que le '),
unistr('suministre la totalidad de los datos, ni enviara mail requiriendo informaci\00F3n personal '),
'alguna.</b></li>',
'</p>',
'</ul></p>',
'<ul>',
'',
'<li><b>Costo del Servicio :</b></li>',
'<p>',
unistr('<li type="circle" style="margin-left: 30px;">La empresa PROYECTO-VISION  podr\00E1 cobrar comisiones por el mantenimiento y/o uso de este '),
unistr('Servicio o los que en el futuro implemente, entendi\00E9ndose facultado expresamente para '),
unistr('efectuar los correspondientes d\00E9bitos en mis cuentas, a\00FAn en descubierto, por lo que '),
unistr('presto para ello mi expresa conformidad. En caso de cualquier modificaci\00F3n a la '),
unistr('presente previsi\00F3n, lo comunicar\00E1 con al menos 60 d\00EDas de antelaci\00F3n. </li>'),
'</ul></p>',
'<ul>',
'<li><b>Vigencia:</b></li>',
'<p>',
unistr('<li type="circle" style="margin-left: 30px;">El Usuario podr\00E1 dejar sin efecto la relaci\00F3n que surja de la presente, en forma '),
'inmediata, sin otra responsabilidad que la derivada de los gastos originados hasta ese ',
'momento.</li>',
'<li type="circle" style="margin-left: 30px;">Si el cliente incumpliera cualquiera de las obligaciones asumidas en su ',
unistr('relaci\00F3n contractual con  PROYECTO-VISION , o de los presentes T\00E9rminos y Condiciones, el '),
unistr('Banco podr\00E1 decretar la caducidad del presente Servicio en forma inmediata, sin que '),
unistr('ello genere derecho a indemnizaci\00F3n o compensaci\00F3n alguna.</li>'),
unistr('<li type="circle" style="margin-left: 30px;text-transform: uppercase;"><b>PROYECTO-VISION podr\00E1 dejar '),
unistr('sin efecto la relaci\00F3n que surja de la presente, con un preaviso m\00EDnimo de 60 d\00EDas, sin otra responsabilidad.</b></li>'),
'</ul></p>',
'<ul>',
'<li><b>Validez de operaciones y notificaciones: </b></li>',
'<p>',
unistr('<li type="circle" style="margin-left: 30px;">Los registros emitidos por la app ser\00E1n prueba suficiente de las operaciones cursadas '),
'por dicho canal. </li>',
'<li type="circle" style="margin-left: 30px;">Renuncio expresamente a cuestionar la idoneidad o habilidad de ese medio de prueba.</li>',
'<li type="circle" style="margin-left: 30px;">A los efectos del cumplimiento de disposiciones legales o ',
'contractuales, se otorga a las notificaciones por este medio el mismo alcance de las ',
'notificaciones mediante documento escrito.</li>',
'</ul></p>',
'',
'<ul>',
'<li><b>Propiedad intelectual: </b></li>',
'<p>',
unistr('<li type="circle" style="margin-left: 30px;text-transform: uppercase;"><b>El software en Argentina est\00E1 protegido por la ley 11.723, que regula la propiedad  intelectual y los derechos de autor de todos aquellos creadores de obras art\00EDsticas, literar')
||unistr('ias y cient\00EDficas.</b></li>'),
'</ul></p>',
'',
'<ul>',
unistr('<li><b>Privacidad de la informaci\00F3n: </b></li>'),
'<p>',
unistr('<li type="circle" style="margin-left: 30px;">Para utilizar los Servicios ofrecidos por PROYECTO-VISION , los Usuarios deber\00E1n facilitar determinados datos de car\00E1cter personal.</li>'),
unistr('<li type="circle" style="margin-left: 30px;">Su informaci\00F3n personal se procesa y almacena en servidores o medios magn\00E9ticos que mantienen altos est\00E1ndares de seguridad y protecci\00F3n tanto f\00EDsica como tecnol\00F3gica.</li>'),
unistr('<li type="circle" style="margin-left: 30px;">Para mayor informaci\00F3n sobre la privacidad de los Datos Personales y casos en los que ser\00E1 revelada la informaci\00F3n personal, se pueden consultar nuestras pol\00EDticas de privacidad.</li>'),
'</ul></p>',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
