prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>32
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'ABM PEDIDO'
,p_alias=>'ABM-PEDIDO'
,p_step_title=>'ABM PEDIDO'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210603065637'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10993879663430940)
,p_plug_name=>'ABM Pedido'
,p_region_name=>'RCAB'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(10556002874422924)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(10993987061430941)
,p_name=>'Datos Principales'
,p_parent_plug_id=>wwv_flow_api.id(10993879663430940)
,p_template=>wwv_flow_api.id(10527637074422900)
,p_display_sequence=>2
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select NROFACT "N\00FAmero de Factura",'),
'       PESO "PESO del Pedido",',
unistr('       NROCLIENT "N\00FAmero de Cliente"'),
'  from PEDIDO p',
'  where p.id=:P32_ID',
'  order by p.id'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(10578545313422943)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(10994754168430949)
,p_query_column_id=>1
,p_column_alias=>unistr('N\00FAmero de Factura')
,p_column_display_sequence=>10
,p_column_heading=>unistr('N\00FAmero De Factura')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13603034589256338)
,p_query_column_id=>2
,p_column_alias=>'PESO del Pedido'
,p_column_display_sequence=>40
,p_column_heading=>'Peso Del Pedido'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13599308247256301)
,p_query_column_id=>3
,p_column_alias=>unistr('N\00FAmero de Cliente')
,p_column_display_sequence=>30
,p_column_heading=>unistr('N\00FAmero De Cliente')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(13599876777256306)
,p_name=>'Datos Principales2'
,p_parent_plug_id=>wwv_flow_api.id(10993879663430940)
,p_template=>wwv_flow_api.id(10527637074422900)
,p_display_sequence=>12
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       FECHAPEDIDO "Fecha del Pedido",',
'       FECHAENTREGA "Fecha de Entrega",',
'       IDESTADOPEDIDO "Estado del Pedido"',
'  from PEDIDO p',
'  where p.id=:P32_ID',
'  order by p.id'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(10578545313422943)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13600251706256310)
,p_query_column_id=>1
,p_column_alias=>'Fecha del Pedido'
,p_column_display_sequence=>40
,p_column_heading=>'Fecha Del Pedido'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13600365035256311)
,p_query_column_id=>2
,p_column_alias=>'Fecha de Entrega'
,p_column_display_sequence=>50
,p_column_heading=>'Fecha De Entrega'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13600418482256312)
,p_query_column_id=>3
,p_column_alias=>'Estado del Pedido'
,p_column_display_sequence=>60
,p_column_heading=>'Estado Del Pedido'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(13600502042256313)
,p_name=>'Detalle del Pedido'
,p_region_name=>'RPROD'
,p_template=>wwv_flow_api.id(10556002874422924)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       IDPIEZA,',
'       dp.CANTIDAD,',
'       PRECIOUNI,',
'       TOTAL,',
'       p.id',
'  from DETALLEPEDIDO dp,',
'  pedido p',
'  where dp.idpedido=p.id',
'  and p.id=:P32_ID'))
,p_header=>'Detalle del Pedido'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P32_ID'
,p_query_row_template=>wwv_flow_api.id(10578545313422943)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13601472887256322)
,p_query_column_id=>1
,p_column_alias=>'IDPIEZA'
,p_column_display_sequence=>20
,p_column_heading=>'Idpieza'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13601569871256323)
,p_query_column_id=>2
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>30
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13601696389256324)
,p_query_column_id=>3
,p_column_alias=>'PRECIOUNI'
,p_column_display_sequence=>40
,p_column_heading=>'Preciouni'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13601749971256325)
,p_query_column_id=>4
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>50
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(13602007465256328)
,p_query_column_id=>5
,p_column_alias=>'ID'
,p_column_display_sequence=>60
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(13601236046256320)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(13600502042256313)
,p_button_name=>'AgregarProd'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_api.id(10617873927422977)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Producto'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,18:P18_ID:'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(13599747792256305)
,p_name=>'P32_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(10993879663430940)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.component_end;
end;
/
