prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Entregas'
,p_alias=>'ENTREGAS'
,p_step_title=>'Entregas'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624033911'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(12447578473094647)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.ID,',
'       NROFACTURA,',
'       c.nomb||'' ''||c.apel,',
'       HORARIOENTREGA,',
'       fe.nomb "Forma de Entrega",',
'       FECHENTREGA,',
unistr('       ea.nomb "Estado Aceptaci\00F3n",'),
'       IDPEDIDO,',
'        en.nomb "Estado Entrega",',
'        dm.nomb,',
'        idCOSTO,',
'        sys.dbms_lob.getlength(FILE_BLOB) Descargar',
'  from ENTREGAS e,',
'  estadoentrega en,',
'  clientes c,',
'  estadosaceptacion ea,',
'  formasEntregas fe,',
'  dm$sino dm',
'  where e.IDESTADO=en.id',
'  and e.idCliente=c.id',
'  and e.IDESTADOACEPTACION=ea.id',
'  and e.IDFORMAENTREGA=fe.id',
'  and e.constancia=dm.id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(12447978502094648)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'PDF'
,p_detail_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,:P24_ID:#ID#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DEMO'
,p_internal_uid=>12447978502094648
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(12448066950094648)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>unistr('N\00B0 Entrega')
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10993307574430935)
,p_db_column_name=>'FECHENTREGA'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>'Fechentrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10993555247430937)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>70
,p_column_identifier=>'V'
,p_column_label=>unistr('N\00B0 Pedido')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16397292161904735)
,p_db_column_name=>'NROFACTURA'
,p_display_order=>80
,p_column_identifier=>'Y'
,p_column_label=>unistr('N\00B0 Factura')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16939147779540502)
,p_db_column_name=>'HORARIOENTREGA'
,p_display_order=>160
,p_column_identifier=>'AI'
,p_column_label=>'Horarioentrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16939297982540503)
,p_db_column_name=>'IDCOSTO'
,p_display_order=>170
,p_column_identifier=>'AJ'
,p_column_label=>unistr('COSTO DE ENV\00CDO')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16941050487540521)
,p_db_column_name=>'C.NOMB||''''||C.APEL'
,p_display_order=>180
,p_column_identifier=>'AV'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16941163138540522)
,p_db_column_name=>'Forma de Entrega'
,p_display_order=>190
,p_column_identifier=>'AW'
,p_column_label=>'Forma De Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16941216578540523)
,p_db_column_name=>unistr('Estado Aceptaci\00F3n')
,p_display_order=>200
,p_column_identifier=>'AX'
,p_column_label=>unistr('Estado Aceptaci\00F3n')
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16941351480540524)
,p_db_column_name=>'Estado Entrega'
,p_display_order=>210
,p_column_identifier=>'AY'
,p_column_label=>'Estado Entrega'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16941462878540525)
,p_db_column_name=>'NOMB'
,p_display_order=>220
,p_column_identifier=>'AZ'
,p_column_label=>'Comprobante'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16943022376540541)
,p_db_column_name=>'DESCARGAR'
,p_display_order=>230
,p_column_identifier=>'BD'
,p_column_label=>'Comprobante Adjunto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:ENTREGAS:FILE_BLOB:ID::FILE_MIMETYPE:FILENAME:UPDATED:FILE_CHARSET:attachment:Descargar:'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(12455560400114098)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'124556'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('ID:IDPEDIDO:FECHENTREGAACEPTACION:NROFACTURA:IDCOSTO:IDFORMAENTREGAACEPTACION:C.NOMB||''''||C.APEL:Forma de Entrega:Estado Aceptaci\00F3n:Estado Entrega:NOMB:DESCARGAR')
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(12452543686094651)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(12447578473094647)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10618584427422979)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar Entrega'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:24'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16939423579540505)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(12447578473094647)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(10618671698422979)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'DESCARGAR COMPROBANTE PARA COMPLETAR'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'#APP_IMAGES#COMPROBANTE DE ENTREGA.pdf'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(12451578601094651)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(12447578473094647)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(12452047562094651)
,p_event_id=>wwv_flow_api.id(12451578601094651)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(12447578473094647)
);
wwv_flow_api.component_end;
end;
/
