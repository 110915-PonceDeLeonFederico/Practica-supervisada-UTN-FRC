prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>unistr('Reporte Tiempos de Fabricaci\00F3n')
,p_alias=>unistr('REPORTE-TIEMPOS-DE-FABRICACI\00D3N')
,p_step_title=>unistr('Reporte Tiempos de Fabricaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624051921'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10932613956009745)
,p_plug_name=>unistr('Reporte Tiempos de Fabricaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
unistr('COMO personal de gesti\00F3n de stock QUIERO consultar los tiempos de fabricaci\00F3n'),
unistr(' PARA saber cu\00E1l es el tiempo de fabricaci\00F3n que tiene para hacer esas piezas.*/'),
'',
unistr(' select pie.nomb "Pieza",p.TIEMPOFABR "Tiempo de fabricaci\00F3n por piezas"'),
' from productos p,',
' piezas pie',
' where pie.id=p.idPieza',
' group by pie.nomb,p.TIEMPOFABR'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>unistr('Reporte Tiempos de Fabricaci\00F3n')
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10932776475009745)
,p_name=>unistr('Reporte Tiempos de Fabricaci\00F3n')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>10932776475009745
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819529409446121)
,p_db_column_name=>'Pieza'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819666082446122)
,p_db_column_name=>unistr('Tiempo de fabricaci\00F3n por piezas')
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>unistr('Tiempo De Fabricaci\00F3n Por Piezas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10933529507010001)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'109336'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Pieza:Tiempo de fabricaci\00F3n por piezas')
,p_chart_type=>'bar'
,p_chart_label_column=>'Pieza'
,p_chart_label_title=>'Piezas'
,p_chart_value_column=>unistr('Tiempo de fabricaci\00F3n por piezas')
,p_chart_aggregate=>'SUM'
,p_chart_value_title=>'Horas'
,p_chart_sorting=>'VALUE_ASC'
,p_chart_orientation=>'vertical'
);
wwv_flow_api.component_end;
end;
/
