prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'PRODUCTOS'
,p_alias=>'PRODUCTOS'
,p_step_title=>'PRODUCTOS'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624055133'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(16438066723936057)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       pi.nomb "Pieza",',
unistr('       ''$''||COSTO "Costo de Fabricaci\00F3n",'),
'       MEDIDASALT||''mm'' "Largo Pieza",',
'       MEDIDASANCH||''mm'' "Ancho Pieza",',
'       CANTPROD"Cantidad",',
unistr('       TIEMPOFABR "Tiempo Fabricaci\00F3n (Hs)",'),
'       m.nomb "Material",',
'       PESO||'' Kg'',',
unistr('       FECHAPROD "Fecha de Producci\00F3n",'),
'       OBSERVACIONES,',
'       e.nomb "Estado"',
'  from PRODUCTOS P,',
'  Piezas pi,',
'  Estados e,',
'  Materiales m',
'  where p.idPieza=pi.id',
'  and p.IDMATERIAL=m.id',
'  and p.IDESTADOPIEZA=e.id',
'  order by P.ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(16438404031936058)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,:P3_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'DEMO'
,p_internal_uid=>16438404031936058
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16438555300936060)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16442588716936064)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395108651904714)
,p_db_column_name=>'Pieza'
,p_display_order=>21
,p_column_identifier=>'N'
,p_column_label=>'Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395234366904715)
,p_db_column_name=>unistr('Costo de Fabricaci\00F3n')
,p_display_order=>31
,p_column_identifier=>'O'
,p_column_label=>unistr('Costo De Fabricaci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395358966904716)
,p_db_column_name=>'Largo Pieza'
,p_display_order=>41
,p_column_identifier=>'P'
,p_column_label=>'Largo Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395400152904717)
,p_db_column_name=>'Ancho Pieza'
,p_display_order=>51
,p_column_identifier=>'Q'
,p_column_label=>'Ancho Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395573051904718)
,p_db_column_name=>'Cantidad'
,p_display_order=>61
,p_column_identifier=>'R'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395629694904719)
,p_db_column_name=>unistr('Tiempo Fabricaci\00F3n (Hs)')
,p_display_order=>71
,p_column_identifier=>'S'
,p_column_label=>unistr('Tiempo Fabricaci\00F3n (hs)')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395788846904720)
,p_db_column_name=>'Material'
,p_display_order=>81
,p_column_identifier=>'T'
,p_column_label=>'Material'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395802986904721)
,p_db_column_name=>unistr('Fecha de Producci\00F3n')
,p_display_order=>91
,p_column_identifier=>'U'
,p_column_label=>unistr('Fecha De Producci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16395967482904722)
,p_db_column_name=>'Estado'
,p_display_order=>101
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(16396086062904723)
,p_db_column_name=>'PESO||''KG'''
,p_display_order=>111
,p_column_identifier=>'W'
,p_column_label=>'Peso'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(16445107316936552)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'164452'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('Pieza:Cantidad:Material:Costo de Fabricaci\00F3n:Tiempo Fabricaci\00F3n (Hs):Fecha de Producci\00F3n:Largo Pieza:Ancho Pieza:OBSERVACIONES:Estado::PESO||''KG''')
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(16444796604936067)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(16438066723936057)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(10618584427422979)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nuevo Producto'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3::'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(16443753687936065)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(16438066723936057)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(16444221681936066)
,p_event_id=>wwv_flow_api.id(16443753687936065)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(16438066723936057)
);
wwv_flow_api.component_end;
end;
/
