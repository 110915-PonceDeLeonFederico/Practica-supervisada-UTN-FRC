prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>9591338837964569
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DEMO'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(10641264060423029)
,p_name=>'Reporte Piezas Fabricadas'
,p_alias=>'CONSULTAR-INVENTARIO-DE-LAS-PIEZAS-FABRICADAS'
,p_step_title=>'Reporte Piezas Fabricadas'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'DEMO'
,p_last_upd_yyyymmddhh24miss=>'20210624051808'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10923121154904109)
,p_plug_name=>'Reporte Piezas Fabricadas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(10554141165422921)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*',
'',
unistr('COMO personal de gesti\00F3n de stock QUIERO consultar el inventario de las piezas finalizadas PARA saber'),
unistr(' cu\00E1ntas piezas finalizados, en proceso, en falta que tenemos actualmente.*/'),
'',
' select pie.nomb "Pieza",e.nomb "Estado",sum(p.CANTPROD) "Cantidad de Piezas Actualmente"',
' from productos p,',
' estados e,',
' piezas pie',
' where p.IDESTADOPIEZA=e.id',
' and pie.id=p.idPieza',
' and e.id=3',
' group by pie.nomb,e.nomb'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte Piezas Fabricadas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(10923231247904109)
,p_name=>'Consultar inventario de las piezas fabricadas'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DEMO'
,p_internal_uid=>10923231247904109
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819164293446117)
,p_db_column_name=>'Pieza'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Pieza'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819264428446118)
,p_db_column_name=>'Estado'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(10819489988446120)
,p_db_column_name=>'Cantidad de Piezas Actualmente'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Cantidad De Piezas Actualmente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(10924068434904524)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'CHART'
,p_report_alias=>'109241'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'Pieza:Estado:Cantidad de Piezas Actualmente'
,p_chart_type=>'pie'
,p_chart_label_column=>'Pieza'
,p_chart_value_column=>'Cantidad de Piezas Actualmente'
,p_chart_aggregate=>'SUM'
,p_chart_sorting=>'VALUE_ASC'
,p_chart_orientation=>'vertical'
);
wwv_flow_api.component_end;
end;
/
